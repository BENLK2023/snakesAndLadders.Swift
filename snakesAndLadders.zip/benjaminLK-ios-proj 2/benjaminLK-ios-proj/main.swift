/** initializing the array*/

var sortedPlayers:[Player] = []
let players1 = Player(name: "Philip")
let players2 = Player(name: "Alex")
let players3 = Player(name: "Michael")
let players4 = Player(name: "Benjamin")
sortedPlayers.append(players1)
sortedPlayers.append(players2)
sortedPlayers.append(players3)
sortedPlayers.append(players4)

/**sorting the array with the tie breaker**/
sortedPlayers = orderPlayers(sortedPlayers)
/**reseting the value of roll within players to 0 before starting the game**/
for i in sortedPlayers{
    i.roll = 0
}
/**initializing the game based on the array being sorted by the tiebreaker**/
playSnakesAndLadders(players: sortedPlayers)



