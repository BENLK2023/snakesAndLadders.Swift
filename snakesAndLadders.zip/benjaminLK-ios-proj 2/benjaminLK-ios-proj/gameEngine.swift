func rollDice ()->Int {
    let value = Int.random(in: 1 ... 6)
    return value
}


func playSnakesAndLadders(players: [Player]){
    
    print("\n***The Game Starts!***")
    var won = false
    whileLoop: while won == false {
        
        for player in players {
            var playerScore = player.roll
            let diceValue = rollDice()
            print("It's \(player.name)'s turn")
            print("\(player.name) is currently on square \(playerScore)")
            print("\(player.name) rolled \(diceValue)")
            playerScore += diceValue
            //if players go past 100
            if playerScore > 100 {
                playerScore = 100 - (playerScore-100)
                print("\(player.name) rolled past 100, your new sqare will be \(playerScore)")
            }
            if (checkSpace(variable: playerScore) != playerScore) {
                snakeOrLadder(players: [player], current: playerScore, destination: checkSpace(variable: playerScore))
                playerScore = checkSpace(variable: playerScore)
            } else if playerScore < 100 {
                print("\(player.name) moved to square: \(playerScore)" )
            } else if playerScore == 100{
                won = true
                print("\(player.name) made it to square 100!")
                print("\(player.name) IS THE WINNER")
                break whileLoop
            }
            print("-----------------------------")
            player.roll = playerScore
        }
    }
}
