class Player : Equatable, Comparable, CustomStringConvertible {
    let name : String
    var roll : Int = 0
    var value: Int = 0
    
    func rollDice() -> Int {
       roll = Int.random(in: 1...6)
       return roll
    }
    func valuePlusRoll() -> Int {
       value += roll
       return value
    }
    static func < (lhs: Player, rhs: Player) -> Bool {
        return lhs.value < rhs.value
    }
    
    static func == (lhs: Player, rhs: Player) -> Bool {
        return lhs.value == rhs.value
    }
    
    init(name : String) {
        self.name = name
    }
    
    func calcSumValue() -> Int {
    value += roll
    return value
    }
    
    var description: String {
        return "\(name) + \(roll)"
    }
}

func printPlayers(players: [Player]) {
    for friendEntry in players {
        print("Name: \(friendEntry.name)")
    }
}
