func whenTied(_ sortedPlayers: [Player])-> Bool{
    var ifTies = false
    for i in 0...sortedPlayers.count-2{
       if sortedPlayers[i] == sortedPlayers[i + 1] {
           ifTies = true
       }
    }
    if !ifTies {
        print("\nFinal player order:\n")
        for player in sortedPlayers {
            print("\(player.name)")
        }
    }
    return ifTies
}

func whoStarts (_ sortedPlayers: [Player]) -> [Player]{
   var sortedPlayers = sortedPlayers
   var before = 0
   var after: Int

    repeat {
        after = sortedPlayers.lastIndex(of: sortedPlayers[before]) ?? before
        if before == after {
           before += 1
        }
        else {
             print("\nA tie has occured between: ", terminator: "")
             for i in (before...after) {
                 print("\(sortedPlayers[i].name)", terminator: "")
                 if i <= (after-1) {
                    print(" and ", terminator: "")
                 }
             }
             print(" will roll again to break the tie.\n")
             for i in before...after{
                 sortedPlayers[i].rollDice()
                 sortedPlayers[i].valuePlusRoll()
                 print("\(sortedPlayers[i].name) rolled \(sortedPlayers[i].roll).")
             }
             for i in 0..<before{
                 sortedPlayers[i].value += 6
             }
                sortedPlayers = sortedPlayers.sorted(by: >)
        }
    }
    while before < (sortedPlayers.count - 1)
        let finalOrder = sortedPlayers
        print("\nFinal player order is: ")
        for player in sortedPlayers {
            print("\(player.name)")
        }
        return finalOrder
}

func orderPlayers (_ players: [Player]) -> [Player] {
    for player in players {
        player.rollDice()
        player.valuePlusRoll()
    }
    let sortedPlayers = players.sorted(by: >)
    for player in sortedPlayers{
      print("\(player.name) rolled a \(player.roll)" )
    }
    if whenTied(sortedPlayers) {
        return whoStarts(sortedPlayers)
    } else { return sortedPlayers }
}
