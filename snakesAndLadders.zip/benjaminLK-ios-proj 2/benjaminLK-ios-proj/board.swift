/**Initializing the board, its important that the value in the array matches
 the index since i use that logic in my snakeOrLadder function.**/

var board=[0,38,2,3,14,5,6,7,8,31,10,        // 1-10
           11,12,13,14,15,6,17,18,19,20,   // 11-20
           42,22,23,24,25,26,27,84,29,30,  // 21-30
           31,32,33,34,35,44,37,38,39,40,  // 31-40
           41,42,43,44,45,46,47,30,49,50,  // 41-50
           67,52,53,54,55,56,57,58,59,60,  // 51-60
           61,62,63,60,65,66,67,68,69,70,  // 61-70
           91,72,73,74,75,76,77,78,19,100, // 71-80
           81,82,83,84,85,86,87,88,89,90,  // 81-90
           91,92,68,94,24,96,76,78,99,100]

func checkSpace( variable: Int)->(Int){
    return board[variable]
}

func snakeOrLadder(players: [Player], current:Int , destination:Int){
    for player in players{
        if (current < destination) {
            print("\(player.name) found a ladder! Climb up to space  \(destination)")
        } else if (current > destination) {
            print("Oh NO! \(player.name) found a snake! Slide down to space \(destination)")
        }
    }
}
